# Findings: Property Revenue Dashboard — Bug Investigation

Three planted bugs map exactly to the three complaints. A fourth design flaw
amplifies the leak. All are verified against the seed data (`database/seed.sql`).

---

## Bug 1 — Cross-tenant cache leak  → Ocean Rentals' privacy complaint

**File:** `backend/app/services/cache.py` line 13
**Root cause:** `cache_key = f"revenue:{property_id}"` — no tenant in the key.
Property IDs are only unique **per tenant** (`properties` has composite PK
`(id, tenant_id)`), and the seed data deliberately gives BOTH tenants a
`prop-001`:

| id | tenant | name | timezone |
|---|---|---|---|
| prop-001 | tenant-a | Beach House Alpha | Europe/Paris |
| prop-001 | tenant-b | Mountain Lodge Beta | America/New_York |

**Mechanism:** Sunset views prop-001 → result cached under `revenue:prop-001`
(payload even contains `"tenant_id": "tenant-a"`). Ocean requests THEIR
prop-001 within the 300s TTL → gets Sunset's numbers. After TTL expiry the
order can reverse. Cache hit vs miss is why it happens "sometimes on refresh".

**Fix:** `cache_key = f"revenue:{tenant_id}:{property_id}"` (+ per-period key
for monthly). After deploy, poisoned keys age out in ≤5 min, or flush:
`docker compose exec redis redis-cli FLUSHDB`.

**Repro (pre-fix):** login Sunset → open prop-001 (2250.00, count 4) → login
Ocean (incognito) → open prop-001 → shows 2250.00 with `tenant_id: tenant-a`
in the raw payload. Post-fix Ocean correctly sees 0.00 / 0 (Mountain Lodge
Beta has no seeded bookings).

---

## Bug 2 — UTC month bucketing ignores property timezone → Sunset's March mismatch

**File:** `backend/app/services/reservations.py`, `calculate_monthly_revenue`
**Root causes (two in one function):**
1. Month boundaries built with naive `datetime(year, month, 1)` — i.e. UTC —
   never the property's timezone (schema even has a `timezone` column).
2. The signature doesn't accept `tenant_id` at all, though its own SQL
   references `tenant_id = $2` — the query was never tenant-scopable.

**Smoking gun:** seed reservation `res-tz-1`: check-in `2024-02-29 23:30 UTC`,
amount 1250.000, property in Europe/Paris. In Paris local time that is
`2024-03-01 00:30` — **March**. Client's internal records (local time) count
it in March; UTC bucketing puts it in February.

| prop-001 (tenant-a) March total | value |
|---|---|
| Old (UTC bucketing) | 1000.00 |
| Fixed (Paris local) | **2250.00** |
| Gap | 1250.00 = exactly res-tz-1 |

**Fix:** look up the property's timezone, build month boundaries at local
midnight, convert to UTC, query `check_in_date >= :start_utc AND < :end_utc`,
scoped by tenant. Bonus correctness: the fixed March window ends `Mar 31
22:00Z`, not `23:00Z` — Paris enters DST on 2024-03-31 (handled by zoneinfo).
Wired into the API as optional `month`/`year` params on `/dashboard/summary`
so the fix is demonstrable in Swagger.

---

## Bug 3 — Money through binary floats → finance's "few cents off"

**Files:** `backend/app/api/v1/dashboard.py` line 18; `frontend/src/components/RevenueSummary.tsx` line 64
**Root cause:** DB stores `NUMERIC(10,3)` (sub-cent, e.g. 333.333). The DB sum
is exact; then the API does `float(revenue_data['total'])` — binary floats
cannot represent decimal cents — and the frontend double-rounds with
`Math.round(total * 100) / 100`.

**Demonstrable failures** (see `verify_bugs.py`):
- `1080.40 * 100 → 108040.00000000001`
- `Math.round(1.005 * 100)/100 → 1.00` (correct half-up answer: **1.01**)
- float sum of the 333.333/333.333/333.334 trio silently drops the exactness
  the schema was designed to keep (1000.0 float vs 1000.000 decimal).

**Fix:** money stays `Decimal` end-to-end; ONE explicit rounding step at the
API boundary (`quantize(0.01, ROUND_HALF_UP)`); serialized as **strings**
(`total_revenue`, plus `total_revenue_exact` for audit). Frontend renders the
pre-rounded string (Number() used only for locale thousands-separators — no
arithmetic). Sub-cent remainder indicator now compares exact vs displayed.

---

## Bug 4 (design flaw, flagged) — Hardcoded cross-tenant property list

**File:** `frontend/src/components/Dashboard.tsx` lines 4-10 hardcodes all
five property names from BOTH tenants for every logged-in client — Ocean sees
"Beach House Alpha", Sunset sees "Lakeside Cottage". Proper fix is a
tenant-scoped `GET /properties` endpoint; that's new surface area ("do NOT
rebuild"), so it is flagged with a recommendation rather than built.

## Additional observations (mention in video, no code change)

- `tenant_resolver.py` defaults unknown users to **tenant-a** — dangerous
  default; should deny instead. (Fixed the equivalent flaw in dashboard.py:
  `"default_tenant"` fallback → now 403 if tenant unresolved.)
- `calculate_total_revenue` falls back to **fabricated mock revenue** on DB
  errors — masks outages with fake financials. Flagged in code, kept for
  local demo continuity. If prop-001 shows 1000.00/count 3 for Sunset, your
  DB isn't connected (mock data); the real DB answer is 2250.00/count 4.
- Frontend sent an `X-Simulated-Tenant: candidate` header the backend never
  reads — removed as misleading dead code. Tenant identity comes from JWT.
- `NUMERIC(10,3)` sub-cent storage is a policy question: either round at
  booking-write time or keep 3dp and document the display rounding (done).

## Expected totals after fixes (from seed data)

| Tenant | Property | All-time | Count |
|---|---|---|---|
| tenant-a | prop-001 | 2250.00 | 4 |
| tenant-a | prop-002 | 4975.50 | 4 |
| tenant-a | prop-003 | 6100.50 | 2 |
| tenant-b | prop-001 | 0.00 | 0 |
| tenant-b | prop-004 | 1776.50 | 4 |
| tenant-b | prop-005 | 3256.00 | 3 |

---

# Full-codebase sweep (privacy & best-practice audit)

Verified clean:
- **Auth coverage:** every `api/v1` module requires `authenticate_request` except `login.py` (login/logout — correctly public).
- **CORS:** restricted to localhost dev origins, not `*`. OK.
- **Frontend caching:** `SecureAPI`'s 5s in-memory GET cache is cleared on token
  change (`setAccessToken` → `clearCache()`), and the dashboard call adds a
  `_t` cache-buster. `secureLogout.ts` scrubs storage on logout. No frontend
  cross-tenant leak in the assessed path.

Report-only observations (worth 30 seconds in the video — same bug CLASS as Bug 1):
- **`core/token_service.py`:** cache keys fall back to UNSCOPED when tenant_id
  is None (`"stripe:secret"`, `"hostaway:{city}"`). If ever hit with a missing
  tenant, one tenant's Stripe/Hostaway credentials could be served to another.
  Recommendation: raise instead of falling back to a shared key.
- **`config.py`:** hardcoded JWT `secret_key = "debug_challenge_secret"` —
  fine for this challenge, but in production anyone reading the repo can forge
  tokens. Must come from env/secret manager.
- **`frontend/src/lib/cache.ts` (FinanceCache):** unused, tenant-UNscoped
  3-hour localStorage cache designed for financial data. Delete it or scope
  keys by tenant before anyone wires it up.

Performance note (if asked about efficiency/DSA):
- Aggregation is done where it belongs — `SUM`/`COUNT` in SQL (single O(n)
  scan server-side), Redis O(1) lookups in front. For scale, recommend a
  composite index: `CREATE INDEX idx_res_tenant_prop_checkin ON
  reservations (tenant_id, property_id, check_in_date);` — left as a
  recommendation since schema migrations edge toward "rebuilding".
