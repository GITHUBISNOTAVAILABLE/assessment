import json
import redis.asyncio as redis
from typing import Dict, Any, Optional
import os

# Initialize Redis client (typically configured centrally).
redis_client = redis.Redis.from_url(os.getenv("REDIS_URL", "redis://localhost:6379/0"))

async def get_revenue_summary(
    property_id: str,
    tenant_id: str,
    month: Optional[int] = None,
    year: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Fetches revenue summary, utilizing caching to improve performance.

    BUGFIX (tenant isolation): the cache key MUST include the tenant_id.
    Property IDs are only unique per tenant (properties has a composite
    PK of (id, tenant_id) - both tenants own a 'prop-001'), so the old key
    f"revenue:{property_id}" served one tenant's cached revenue to the
    other tenant for up to the 5-minute TTL. That is the cross-tenant
    data leak Ocean Rentals reported.
    """
    if month and year:
        cache_key = f"revenue:{tenant_id}:{property_id}:{year}-{month:02d}"
    else:
        cache_key = f"revenue:{tenant_id}:{property_id}"

    # Try to get from cache
    cached = await redis_client.get(cache_key)
    if cached:
        return json.loads(cached)

    # Revenue calculation is delegated to the reservation service.
    from app.services.reservations import calculate_total_revenue, calculate_monthly_revenue

    # Calculate revenue
    if month and year:
        result = await calculate_monthly_revenue(property_id, tenant_id, month, year)
    else:
        result = await calculate_total_revenue(property_id, tenant_id)

    # Cache the result for 5 minutes
    await redis_client.setex(cache_key, 300, json.dumps(result))

    return result
